package com.cg.rms.dao;

import java.util.List;

import com.cg.rms.bean.CandidateWork;
import com.cg.rms.exception.RmsException;





public interface RmsDao {

	String insertWorkDetails(CandidateWork details) throws RmsException; 
	List<CandidateWork> getAllDetails() throws RmsException;
	boolean updateDetails(CandidateWork details) throws RmsException;
	
	
	
}
