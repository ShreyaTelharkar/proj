package com.cg.rms.dao;


import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import com.cg.rms.bean.CandidateWork;
import com.cg.rms.exception.RmsException;



public class RmsDaoImpl implements RmsDao {
	
Connection conn;
	
private String generateWorkId() throws RmsException{
	
	
	String sql = "SELECT seq_work_id.NEXTVAL FROM DUAL";
	try {
		conn = DBUtil.getConnection();
		Statement st = conn.createStatement();
		ResultSet rst = st.executeQuery(sql);
		rst.next();
		return rst.getString(1);
	} catch (SQLException e) {
		
		throw new RmsException("problem in generating course Id"+e.getMessage());
		//e.printStackTrace();
	}
	

}
	
	@Override
	public String insertWorkDetails(CandidateWork details) throws RmsException {
	String sql = "INSERT INTO candidate_work_history values (?,?,?,?,?,?,?,?,?,?,?,?)";
	
	String id = generateWorkId();
	details.setWork_Id(id);
	
	PreparedStatement pst;
	try {
		conn = DBUtil.getConnection();
		pst = conn.prepareStatement(sql);
		pst.setString(1, details.getWork_Id());
		pst.setString(2, details.getCandidate_Id());
		pst.setString(3, details.getWhich_employer());
		pst.setString(4, details.getContact_person());
		pst.setString(5, details.getPosition_held());
		pst.setString(6, details.getCompany_name());
		pst.setString(7, details.getEmployment_from());
		pst.setString(8, details.getEmployment_to());
		pst.setString(9, details.getReason_For_Leaving());
		pst.setString(10, details.getResponsibilities());
		pst.setString(11, details.getHr_rep_name());
		pst.setString(12, details.getHr_rep_contact_num());
		
		
		pst.executeUpdate();
	} catch (SQLException e) {
		throw new RmsException("problem in inserting the details"+e.getMessage());
		//e.printStackTrace();
	}
	
		
		return id;
	}

	@Override
	public List<CandidateWork> getAllDetails() throws RmsException {
		String sql = "SELECT * FROM candidate_work_history"; //work_id,candidate_id, Which_employer, Contact_person, Position_held, Company_name, Employment_from, Employment_to, Reason_For_Leaving , Responsibilities , Hr_rep_name , Hr_rep_contact_num
		ArrayList<CandidateWork> clist = new ArrayList();
		
		
			Statement st;
			try {
				conn = DBUtil.getConnection();
				st = conn.createStatement();
				ResultSet rst = st.executeQuery(sql);
				CandidateWork c = new CandidateWork();
				while(rst.next()) {
					
					
					
					c.setWork_Id(rst.getString("WORK_ID"));
					
					c.setCandidate_Id(rst.getString("candidate_id"));
					
					c.setWhich_employer(rst.getString("Which_employer"));
					
					c.setContact_person(rst.getString("Contact_person"));
					
					c.setPosition_held(rst.getString("Position_held"));
					
					c.setCompany_name(rst.getString("Company_name"));
					
					c.setEmployment_from(rst.getString("Employement_from"));
					
					c.setEmployment_to(rst.getString("Employement_to"));
					
					c.setReason_For_Leaving(rst.getString("Reason_For_Leaving"));
					
					c.setResponsibilities(rst.getString("Responsibilities"));
					
					c.setHr_rep_name(rst.getString("Hr_rep_name"));
					
					c.setHr_rep_contact_num(rst.getString("Hr_rep_contact_number"));
					
					clist.add(c);
				}
			} catch (SQLException e) {
				
				throw new RmsException("problem in fetching the details"+e.getMessage());
				//e.printStackTrace();
			}
			return clist;
			
			}
			
			
		
		
	

	@Override
	public boolean updateDetails(CandidateWork cource) throws RmsException {
		
		
		Scanner sc = new Scanner(System.in);
		System.out.println("enter work ID");
	String	id = sc.next();
	
	
	
	
		
		String sql = "UPDATE details SET work_id =?, candidate_id=?, Which_employer =?, Contact_person=?, Position_held=?, Company_name=?, Employment_from=?, Employment_to=?, Reason_For_Leaving, Responsibilities , Hr_rep_name, Hr_rep_contact_num   where work_id=?"; 
		
		PreparedStatement pst;
		
		System.out.println("Enter the Details");
		System.out.println("Enter employer name");
		String nm = sc.next();
		System.out.println("enter name of contact person");
		String cper = sc.next();
		System.out.println("enter position held");
		String pos=sc.next();
		System.out.println("enter company name");
		String cnam=sc.next();
		System.out.println("enter employment from");
		String efrom=sc.next();
		System.out.println("enter employment to");
		String eto=sc.next();
		System.out.println("Enter reason for leaving");
		String rlea=sc.next();
		System.out.println("enter responsibilities");
		String res=sc.next();
		System.out.println("enter Hr_rep_name");
		String hrep=sc.next();
		System.out.println("enter Hr_rep_contact_num");
		String hcon=sc.next();
		
		try {
			conn = DBUtil.getConnection();
			pst = conn.prepareStatement(sql);
			
			pst.setString(1, nm );
			pst.setString(2, cper);
			pst.setString(3, pos);
			pst.setString(4, cnam);
			pst.setString(5, efrom);
			pst.setString(6, eto);
			pst.setString(7, rlea);
			pst.setString(8, res);
			pst.setString(9, hrep);
			pst.setString(10, hcon);
			pst.executeUpdate();
		} catch (SQLException e) {
			throw new RmsException("problem in updating the details"+e.getMessage());
			//e.printStackTrace();
		}
		return true;
		
			
	
		}

}
