package com.cg.rms.service;

import java.util.List;

import com.cg.rms.bean.CandidateWork;
import com.cg.rms.dao.RmsDao;
import com.cg.rms.dao.RmsDaoImpl;
import com.cg.rms.exception.RmsException;



public class RmsServiceImpl implements RmsService {
	
	private RmsDao cdao  = new RmsDaoImpl(); 
	@Override
	public String insertWorkDetails(CandidateWork details) throws RmsException {
		
		return cdao.insertWorkDetails(details);
	}
	
	
	
	@Override
	public List<CandidateWork> getAllDetails() throws RmsException {
		
		return cdao.getAllDetails();
	}
	@Override
	public boolean updateWorkDetails(CandidateWork details) throws RmsException {
		
	
		return cdao.updateDetails(details);
	}
		

}
