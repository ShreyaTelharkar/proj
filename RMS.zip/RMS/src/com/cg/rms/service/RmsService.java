package com.cg.rms.service;

import java.sql.Date;
import java.util.List;

import com.cg.rms.bean.CandidateWork;
import com.cg.rms.exception.RmsException;


public interface RmsService {

	
	String insertWorkDetails(CandidateWork details) throws RmsException;
	List<CandidateWork> getAllDetails() throws RmsException;
	boolean updateWorkDetails(CandidateWork details) throws RmsException;
}
