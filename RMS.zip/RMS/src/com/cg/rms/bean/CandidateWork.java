package com.cg.rms.bean;

import java.sql.Date;

public class CandidateWork {
	String work_Id; 
	String candidate_Id;
	String Which_employer;
	String contact_person; 
	String Position_held;
	String Company_name;
	String Employment_from;
	String Employment_to;
	String Reason_For_Leaving;
	String Responsibilities;
	String Hr_rep_name;
	String Hr_rep_contact_num;
	public String getWork_Id() {
		return work_Id;
	}
	public void setWork_Id(String Work_Id) {
		this.work_Id = work_Id;
	}
	public String getCandidate_Id() {
		return candidate_Id;
	}
	public void setCandidate_Id(String Candidate_Id) {
		this.candidate_Id = work_Id;
	}
	public String getWhich_employer() {
		return Which_employer;
	}
	public void setWhich_employer(String which_employer) {
		Which_employer = which_employer;
	}
	public String getContact_person() {
		return contact_person;
	}
	public void setContact_person(String contact_person) {
		this.contact_person = contact_person;
	}
	public String getPosition_held() {
		return Position_held;
	}
	public void setPosition_held(String position_held) {
		Position_held = position_held;
	}
	public String getCompany_name() {
		return Company_name;
	}
	public void setCompany_name(String company_name) {
		Company_name = company_name;
	}
	public String getEmployment_from() {
		return Employment_from;
	}
	public void setEmployment_from(String employment_from) {
		Employment_from = employment_from;
	}
	public String getEmployment_to() {
		return Employment_to;
	}
	public void setEmployment_to(String employment_to) {
		Employment_to = employment_to;
	}
	public String getReason_For_Leaving() {
		return Reason_For_Leaving;
	}
	public void setReason_For_Leaving(String reason_For_Leaving) {
		Reason_For_Leaving = reason_For_Leaving;
	}
	public String getResponsibilities() {
		return Responsibilities;
	}
	public void setResponsibilities(String responsibilities) {
		Responsibilities = responsibilities;
	}
	public String getHr_rep_name() {
		return Hr_rep_name;
	}
	public void setHr_rep_name(String hr_rep_name) {
		Hr_rep_name = hr_rep_name;
	}
	public String getHr_rep_contact_num() {
		return Hr_rep_contact_num;
	}
	public void setHr_rep_contact_num(String Hr_rep_contact_num) {
		Hr_rep_contact_num = Hr_rep_contact_num;
	}
	@Override
	public String toString() {
		return "CandidateWork [work_Id=" + work_Id + ", candidate_Id="
				+ candidate_Id + ", Which_employer=" + Which_employer
				+ ", contact_person=" + contact_person + ", Position_held="
				+ Position_held + ", Company_name=" + Company_name
				+ ", Employment_from=" + Employment_from + ", Employment_to="
				+ Employment_to + ", Reason_For_Leaving=" + Reason_For_Leaving
				+ ", Responsibilities=" + Responsibilities + ", Hr_rep_name="
				+ Hr_rep_name + ", Hr_rep_contact_num=" + Hr_rep_contact_num
				+ "]";
	}
	public CandidateWork(String work_Id, String candidate_Id, String which_employer,
			String contact_person, String position_held, String company_name,
			String employment_from, String employment_to,
			String reason_For_Leaving, String responsibilities,
			String hr_rep_name, String hr_rep_contact_num) {
		super();
		this.work_Id = work_Id;
		this.candidate_Id = candidate_Id;
		Which_employer = which_employer;
		this.contact_person = contact_person;
		Position_held = position_held;
		Company_name = company_name;
		Employment_from = employment_from;
		Employment_to = employment_to;
		Reason_For_Leaving = reason_For_Leaving;
		Responsibilities = responsibilities;
		Hr_rep_name = hr_rep_name;
		Hr_rep_contact_num = hr_rep_contact_num;
	}
	public CandidateWork() {
		super();
		
		// TODO Auto-generated constructor stub
	}

	
}
