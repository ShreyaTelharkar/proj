package com.cg.rms.ui;

import java.util.List;
import java.util.Scanner;

import com.cg.rms.bean.CandidateWork;
import com.cg.rms.exception.RmsException;
import com.cg.rms.service.RmsService;
import com.cg.rms.service.RmsServiceImpl;



public class RmsMain {
	
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		RmsService cser = new RmsServiceImpl();
do {
System.out.println("menu");
System.out.println("1. show all candidate details");
System.out.println("2. Add new candidate work Details");
/*System.out.println("3. delete a course");*/
System.out.println("3. update candidate work Details");
System.out.println("4. exit");
int choice = sc.nextInt();
switch (choice) {
case 1:
	try {
		List<CandidateWork> clist = cser.getAllDetails();
		for (CandidateWork c:clist) {
			System.out.println(c);
		}
	} catch (RmsException e) {
		System.err.println(e.getMessage());
		
		//e.printStackTrace();
	}
	break;
case 2:
	CandidateWork c = new CandidateWork();
	System.out.println("enter candidate id");
	c.setCandidate_Id(sc.next());
	System.out.println("enter name of employer");
	c.setWhich_employer(sc.next());
	System.out.println("enter contact person");
	c.setContact_person(sc.next());
	System.out.println("Enter position held");
	c.setPosition_held(sc.next());
	System.out.println("enter name of company");
	c.setCompany_name(sc.next());
	System.out.println("enter employment from");
	c.setEmployment_from(sc.next());
	System.out.println("Enter employment to");
	c.setEmployment_to(sc.next());
    System.out.println("Enter reason for leaving the company");
    c.setReason_For_Leaving(sc.next());
    System.out.println("Enter responsibilities");
    c.setResponsibilities(sc.next());
    System.out.println("Enter name of HR representative");
    c.setHr_rep_name(sc.next());
    System.out.println("Enter contact number of HR representative");
    c.setHr_rep_contact_num(sc.next());
    
    String cid;
	try {
		cid = cser.insertWorkDetails(c);
		System.out.println("Details added with ID"+cid);
	} catch (RmsException e1) {
		// TODO Auto-generated catch block
		e1.printStackTrace();
	}
	
	break;

case 3:
	System.out.println("enter the candidate  Id to update the details ");
	CandidateWork c1 = new CandidateWork();
	try {
		boolean b = cser.updateWorkDetails(c1);
		if(b) {
			System.out.println("Details updated s");
		}
	} catch (RmsException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	
	break;
case 4:
	
	break;

default:System.out.println("invalid choice");
	
	break;
}
} while (true);
	
	}
}


